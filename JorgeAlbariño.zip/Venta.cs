﻿
namespace JorgeAlbariño
{
    public class Venta
    {
        private int _id;
        private string _comentarios;

        public Venta(int id, string comentarios)
        {
            this._id = id;
            this._comentarios = comentarios;
        }   
    }
}
