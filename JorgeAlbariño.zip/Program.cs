﻿namespace JorgeAlbariño
{
    class ProyectoFinal
    {
        static void Main(string[] args)
        {
                                    
        }

    }
}