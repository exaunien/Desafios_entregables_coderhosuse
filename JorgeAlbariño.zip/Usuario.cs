﻿namespace JorgeAlbariño
{
    public class Usuario
    {
        public int _id;
        public string _name;
        public string _apellido;
        public string _nombreUsuario;
        public string _contraseña;
        public string _mail;

        public Usuario (int id, string name, string apellido, string nombreUsuario, string contraseña,
            string mail )
        {
            this._id = id;
            this._name = name;
            this._apellido = apellido;
            this._nombreUsuario = nombreUsuario;
            this._contraseña = contraseña;
            this._mail = mail;  

            
        }

    }
}
